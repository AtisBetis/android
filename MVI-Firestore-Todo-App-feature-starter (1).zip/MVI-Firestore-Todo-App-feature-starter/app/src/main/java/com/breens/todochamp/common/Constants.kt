package com.breens.todochamp.common

const val SIDE_EFFECTS_KEY = "side-effects_key"

const val COLLECTION_PATH_NAME = "tasks"

const val PLEASE_CHECK_INTERNET_CONNECTION = "Please check your internet connection"